/***Oybek**/


I used Windows OS.
It is spring boot project.
I used MySQL and Postman for optional task (API).


It is not full but that is all I can do

